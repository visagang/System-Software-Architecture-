package com.iit.vm;
//This class inherits the add_cp and is used by VM_1.
public class add_cp1 extends add_cp{

	@Override
	public void add_cp(DataStore ds) {
		// TODO Auto-generated method stud
		int x=ds.get_cp();
		x=x+ds.get_temp_v();
		ds.set_cp(x);	//The method is used to get the current price and add the value specified.It also updates DS_1 about the current price increase
	}

}
