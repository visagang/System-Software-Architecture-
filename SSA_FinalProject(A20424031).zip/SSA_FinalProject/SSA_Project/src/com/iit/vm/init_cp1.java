package com.iit.vm;
//This class inherits the init_cp and is used by VM_1.
public class init_cp1 extends init_cp{

	@Override
	public void init_cp(DataStore ds) {
		// TODO Auto-generated method stub
		ds.set_cp(0);
		System.out.println("CP set to zero");//The method is used to set the current price to zero
	}

}
