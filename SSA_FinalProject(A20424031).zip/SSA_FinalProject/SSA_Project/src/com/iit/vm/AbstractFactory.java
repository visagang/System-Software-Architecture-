package com.iit.vm;
//This is an abstract class and is used to implement the abstract-factory pattern.It contains the class reference to all meta actions...i.e strategy pattern
public abstract class AbstractFactory {
	DataStore datastore;
	public abstract StorePrice createStorePrice();
	public abstract init_cp createinit_cp();
	public abstract returnCoin createreturnCoin();
	public abstract add_cp createadd_cp();
	public abstract dispose_with_add createdispose_with_add();
    public abstract InitializeData CreateInitializeData();
	public abstract DataStore getDataStore();
}
