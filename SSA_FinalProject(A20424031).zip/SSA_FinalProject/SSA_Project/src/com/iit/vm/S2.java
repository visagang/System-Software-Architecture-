package com.iit.vm;
//This class inherits the State class and represent the Idle State.
public class S2 extends State{

	@Override
	public void create() {
		// TODO Auto-generated method stub
		System.out.println("Cannot perform the operation in S2 state");
	}

	@Override
	public void coin(int f) {
		// TODO Auto-generated method stub
		if(f==0) {
			op.add_cp(); //If the value is less than the price, it invokes the add_cp
		}
		if(f==1) {
			op.add_cp();
			m.setState(3);//If the value is more than the price, it invokes the add_cp and changes the state to S3
		}
	}

	@Override
	public void card() {
		// TODO Auto-generated method stub
		op.init_cp();
		m.A[0]=0;
		m.A[1]=0;
		m.A[2]=0;
		m.setState(3);//If the value is more than the card and changes the state to S3
	}

	@Override
	public void additive(int a) {
		// TODO Auto-generated method stub
		System.out.println("Cannot perform the operation in S2 state");
	}

	@Override
	public void dispose_drink() {
		// TODO Auto-generated method stub
		System.out.println("Cannot perform the operation in S2 state");
	}

	@Override
	public void insertCups(int n) {
		// TODO Auto-generated method stub
		if(n>0) {
			m.k =m.k +n; //Increment the number of cups by n
			
		}

	}

	@Override
	public void set_price() {
		// TODO Auto-generated method stub
		op.StorePrice(); //Invoke StorePrice method
	}

	@Override
	public void cancel() {
		// TODO Auto-generated method stub
		System.out.println("Cannot perform the operation in S2 state");
	}

}
