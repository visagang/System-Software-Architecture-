package com.iit.vm;
//This class inherits the StorePrice and is used by VM_2.
public class StorePrice2 extends StorePrice{

	@Override
	public void StorePrice(DataStore ds) {
		// TODO Auto-generated method stub
		ds.set_price(ds.get_temp_p1());
		System.out.println("Price Stored "+ds.get_price1());//The method is used to set the current price
	}

}
