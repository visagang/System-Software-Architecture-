package com.iit.vm;
//It is an abstract class and has abstract methods of all the meta events. It is used to implement the State pattern
public abstract class State {
	 OutputProcessor op;
	 MDAEFSM m;
	 public abstract void create();
	 public abstract void coin(int f);
	 public abstract void card();
	 public abstract void additive(int a);
	 public abstract void dispose_drink();
	 public abstract void insertCups(int n);
	 public abstract void set_price();
	 public abstract void cancel();
	 
	 public void setOP(OutputProcessor op){
		    this.op = op;
	}

	 public void setMDAEFSM(MDAEFSM m){
		    this.m = m;
	}
	 
}
