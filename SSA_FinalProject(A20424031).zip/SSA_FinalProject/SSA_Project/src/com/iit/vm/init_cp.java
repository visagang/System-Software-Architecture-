package com.iit.vm;
//It is an abstract class and contains a constructor with the DataStore variable passed
public abstract class init_cp {
	public abstract void init_cp(DataStore ds);
}
