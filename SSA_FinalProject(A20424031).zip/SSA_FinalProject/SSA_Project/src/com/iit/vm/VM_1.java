package com.iit.vm;

public class VM_1 {
	 private DataStore d;
	 private MDAEFSM m;
	 
	 
	 public void Initialize(AbstractFactory af){
		  d = af.getDataStore();
		  m = new MDAEFSM();
		  m.Initialize(af);
	}
	 
	 void create(int p) {
		 d.set_temp_v(p);
		 m.create(); 
	 }

	 void coin(int v) {
		 d.set_temp_v(v);
		 //System.out.println("The cp value is "+d.get_cp());
		 if (d.get_cp()+v >= d.get_price())
			 m.coin(1);
		 	 //d.set_cp(d.get_cp()+v);
		else 
			m.coin(0);
		 	//d.set_cp(d.get_cp()+v);
		 System.out.println("The cp value is "+d.get_cp());
	 }
	 
	 void card(float x) {
		 if (x>=d.get_price())
			 m.card();
	 }
	 
	 void sugar() {
		 m.additive(0);
	 } 
	 
	 void tea() {
		 d.set_drink_type(1);;
		 m.dispose_drink();
	 }
	
	 void chocolate() {
		 d.set_drink_type(2);
		 m.dispose_drink();
	 }
	 
	 void insert_cups(int n) {
		 m.insertCups(n);
		 System.out.println("Number of cups "+m.k);
	 }
	 
	 void set_price(int p) {
		 d.set_temp_p(p);
		 m.set_price();
	 }
	 
	 void cancel() {
		 m.cancel();
	 }
	 




}
