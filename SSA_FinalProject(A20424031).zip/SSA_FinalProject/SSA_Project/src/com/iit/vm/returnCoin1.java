package com.iit.vm;
//This class inherits the returnCoin and is used by VM_1.
public class returnCoin1 extends returnCoin{

	@Override
	public void returnCoin(DataStore ds) {
		// TODO Auto-generated method stub
		int x=ds.get_cp();
		ds.set_cp(0);//The method is used to set the current price to zero and also returns the amount
		System.out.println("Amount returned "+x+" ");
	}


}
