package com.iit.vm;
//This is an abstract class and is used to store platform dependent data.It contains the the getter and setter methods of all datatypes.

public abstract class DataStore {
	public abstract int get_drink_type();
	public abstract void set_drink_type(int x);
	//VM_1 getter and setter methods
	public abstract int get_temp_p();
	public abstract void set_temp_p(int x);
	public abstract int get_temp_v();
	public abstract void set_temp_v(int x);
	public abstract int get_price();
	public abstract void set_price(int x);
	public abstract int get_cp();
	public abstract void set_cp(int x);
	
	//VM_2 getter and setter methods
	public abstract float get_temp_p1();
	public abstract void set_temp_p(float x);
	public abstract float get_price1();
	public abstract void set_price(float x);
	public abstract float get_cp1();
	public abstract void set_cp(float x);
	public abstract float get_temp_v1();
	public abstract void set_temp_v(float x);
}
