package com.iit.vm;
//This class inherits the add_cp and is used by VM_2.
public class DS_2 extends DataStore{
	private int drink_type;
	private float temp_p;
	private float temp_v;
	private float price;
	private float cp;
	@Override
	public int get_drink_type() {
		// TODO Auto-generated method stub
		return drink_type;
	}

	@Override
	public void set_drink_type(int x) {
		// TODO Auto-generated method stub
		drink_type=x;
	}

	@Override
	public int get_temp_p() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void set_temp_p(int x) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int get_temp_v() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void set_temp_v(int x) {
		// TODO Auto-generated method stub
	
	}

	@Override
	public int get_price() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void set_price(int x) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int get_cp() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void set_cp(int x) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public float get_temp_p1() {
		// TODO Auto-generated method stub
		return temp_p;
	}

	@Override
	public void set_temp_p(float x) {
		// TODO Auto-generated method stub
		temp_p=x;
	}

	@Override
	public float get_price1() {
		// TODO Auto-generated method stub
		return price;
	}

	@Override
	public void set_price(float x) {
		// TODO Auto-generated method stub
		price=x;
	}

	@Override
	public float get_cp1() {
		// TODO Auto-generated method stub
		return cp;
	}

	@Override
	public void set_cp(float x) {
		// TODO Auto-generated method stub
		cp=x;
	}

	@Override
	public float get_temp_v1() {
		// TODO Auto-generated method stub
		return temp_v;
	}

	@Override
	public void set_temp_v(float x) {
		// TODO Auto-generated method stub
		temp_v=x;
	}

}
