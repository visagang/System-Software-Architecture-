package com.iit.vm;
//It is an abstract class and contains a constructor with the DataStore variable an integer array that contains the additives list.
public abstract class dispose_with_add {
	public abstract void dispose_with_add(DataStore ds,int A[]); 
}
