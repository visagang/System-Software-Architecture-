package com.iit.vm;
//It is an abstract class and contains a constructor with the DataStore variable passed
public abstract class StorePrice {
	public abstract void StorePrice(DataStore ds);
}
