package com.iit.vm;
//This class inherits the AbstractFactory and is used by VM_2

public class ConcreteFactory2 extends AbstractFactory{

	@Override
	public StorePrice createStorePrice() {
		// TODO Auto-generated method stub
		return new StorePrice2();//Create a new object of StorePrice2 and returns the pointer
	}

	@Override
	public init_cp createinit_cp() {
		// TODO Auto-generated method stub
		return new init_cp2();//Create a new object of init_cp2 and returns the pointer
	}

	@Override
	public returnCoin createreturnCoin() {
		// TODO Auto-generated method stub
		return new returnCoin2();//Create a new object of returnCoin2 and returns the pointer
	}

	@Override
	public add_cp createadd_cp() {
		// TODO Auto-generated method stub
		return new add_cp2();//Create a new object of add_cp2 and returns the pointer
	}

	@Override
	public dispose_with_add createdispose_with_add() {
		// TODO Auto-generated method stub
		return new dispose_with_add2();//Create a new object of dispose_with_add2 and returns the pointer
	}

	@Override
	public InitializeData CreateInitializeData() {
		// TODO Auto-generated method stub
		return new InitializeData2();//Create a new object of InitializeData2 and returns the pointer
	}

	@Override
	public DataStore getDataStore() {
		// TODO Auto-generated method stub
		if(datastore == null){
		      datastore = new DS_2();//If datastore is not created then, create a new object of DS_2
		    }

		    return datastore;//Returns the datastore pointer
		  }
	
}
