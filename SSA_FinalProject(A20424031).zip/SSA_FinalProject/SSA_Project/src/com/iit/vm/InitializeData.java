package com.iit.vm;
//It is an abstract class and contains a constructor with the DataStore variable passed
public abstract class InitializeData {
	public abstract void InitializeData(DataStore ds);
}
