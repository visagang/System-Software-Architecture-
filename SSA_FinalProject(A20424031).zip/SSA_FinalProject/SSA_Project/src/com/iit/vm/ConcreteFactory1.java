package com.iit.vm;
//This class inherits the AbstractFactory and is used by VM_1
public class ConcreteFactory1 extends AbstractFactory{

	@Override
	public StorePrice createStorePrice() {
		// TODO Auto-generated method stub
		return new StorePrice1(); //Create a new object of StorePrice1 and returns the pointer
	}

	@Override
	public init_cp createinit_cp() {
		// TODO Auto-generated method stub
		return new init_cp1();//Create a new object of init_cp1 and returns the pointer
	}

	@Override
	public returnCoin createreturnCoin() {
		// TODO Auto-generated method stub
		return new returnCoin1();//Create a new object of returnCoin1 and returns the pointer
	}

	@Override
	public add_cp createadd_cp() {
		// TODO Auto-generated method stub
		return new add_cp1();//Create a new object of add_cp1 and returns the pointer
	}

	@Override
	public dispose_with_add createdispose_with_add() {
		// TODO Auto-generated method stub
		return new dispose_with_add1();//Create a new object of dispose_with_add1 and returns the pointer
	}

	@Override
	public InitializeData CreateInitializeData() {
		// TODO Auto-generated method stub
		return new InitializeData1();//Create a new object of InitializeData1 and returns the pointer
	}

	@Override
	public DataStore getDataStore() {
		// TODO Auto-generated method stub
		if(datastore == null){
		      datastore = new DS_1();//If datastore is not created then, create a new object of DS_1
		    }

		    return datastore;//Returns the datastore pointer
		  }
	}


