package com.iit.vm;
//This is Model Independent class that contains a list of meta events to take place
public class MDAEFSM {
	  int k=0; // indicated the number of cups 
	  int A[]=new int[3]; //integer array to represent a list of additives
	  
	  private State[] states;
	  private State state; //points to the state object
	  private int M;
	  
	  public void Initialize(AbstractFactory af) {
		  OutputProcessor op = new OutputProcessor();
		  op.Initialize(af);
		  states = new State[4];
		  states[0] = new S0();
		  states[1] = new S1();
		  states[2] = new S2();
		  states[3] = new S3();
		  state = states[0];
		  for (State s : states) {
		      s.setMDAEFSM(this);
		      s.setOP(op);
		    }
	  }
	  
	  public int getM() {
		    return M;
		  }

	  public void setM(int m) {
		    M = m;
		  }
	  //It is used to invoke the methods of the particular state to which the pointer is assigned.
	  public void create() {
		  state.create();
	  }
	  public void coin(int f) {
		  state.coin(f);
	  }
	  public void card() {
		  state.card();
	  }
	  public void additive(int a) {
		  state.additive(a);
	  }
	  public void dispose_drink() {
		  state.dispose_drink();
	  }
	  public void insertCups(int n) {
		  state.insertCups(n);
	  }
	  public void set_price() {
		  state.set_price();
	  }
	  public void cancel() {
		  state.cancel();
	  }
	  public void setState(int s){
		    state = states[s]; //Set the pointer to the required state object
		  }
}
