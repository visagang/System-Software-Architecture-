package com.iit.vm;
//This class inherits the StorePrice and is used by VM_1.
public class StorePrice1 extends StorePrice{

	@Override
	public void StorePrice(DataStore ds) {
		// TODO Auto-generated method stub
		ds.set_price(ds.get_temp_v());
		System.out.println("Price Stored "+ds.get_price());//The method is used to set the current price
	}

}
