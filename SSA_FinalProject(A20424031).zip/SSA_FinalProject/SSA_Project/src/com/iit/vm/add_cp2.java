package com.iit.vm;

public class add_cp2 extends add_cp{

	@Override
	public void add_cp(DataStore ds) {
		// TODO Auto-generated method stub
		float x=ds.get_cp1();
		x=x+ds.get_temp_v1(); //The method is used to get the current price and add the value specified.It also updates DS_2 about the current price increase
		ds.set_cp(x);
	}

}
