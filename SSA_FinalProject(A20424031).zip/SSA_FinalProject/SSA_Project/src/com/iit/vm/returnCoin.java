package com.iit.vm;
//It is an abstract class and contains a constructor with the DataStore variable passed
public abstract class returnCoin {
	public abstract void returnCoin(DataStore ds);
}
