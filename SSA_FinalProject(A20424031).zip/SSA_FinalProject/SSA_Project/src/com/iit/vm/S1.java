package com.iit.vm;
//This class inherits the State class and represent the No Cups State.
public class S1 extends State{

	@Override
	public void create() {
		// TODO Auto-generated method stub
		System.out.println("Cannot perform the operation in S1 state");
		
	}

	@Override
	public void coin(int f) {
		// TODO Auto-generated method stub
		op.returnCoin();
	}

	@Override
	public void card() {
		// TODO Auto-generated method stub
		System.out.println("Cannot perform the operation in S1 state");
	}

	@Override
	public void additive(int a) {
		// TODO Auto-generated method stub
		System.out.println("Cannot perform the operation in S1 state");
	}

	@Override
	public void dispose_drink() {
		// TODO Auto-generated method stub
		System.out.println("Cannot perform the operation in S1 state");
	}

	@Override
	public void insertCups(int n) {
		// TODO Auto-generated method stub
		if(n>0) {
			m.k=n;
			op.init_cp();
			m.setState(2); //Invokes the init_cp and changes the state to S2
		}
	}

	@Override
	public void set_price() {
		// TODO Auto-generated method stub
		System.out.println("Cannot perform the operation in S1 state");
	}

	@Override
	public void cancel() {
		// TODO Auto-generated method stub
		System.out.println("Cannot perform the operation in S1 state");
	}

}
