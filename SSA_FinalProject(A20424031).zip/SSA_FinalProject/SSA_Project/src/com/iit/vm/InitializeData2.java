package com.iit.vm;
//This class inherits the InitializeData and is used by VM_1.
public class InitializeData2 extends InitializeData{

	@Override
	public void InitializeData(DataStore ds) {
		// TODO Auto-generated method stub
		ds.set_price(0);
		ds.set_drink_type(0);//The method is used to set the current price to zero and the drink type to zero
	}

}
