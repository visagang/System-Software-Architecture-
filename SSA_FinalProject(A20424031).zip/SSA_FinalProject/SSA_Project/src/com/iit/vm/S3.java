package com.iit.vm;
//This class inherits the State class and represent the Coin Inserted State.
public class S3 extends State{

	@Override
	public void create() {
		// TODO Auto-generated method stub
		System.out.println("Cannot perform the operation in S3 state");
	}

	@Override
	public void coin(int f) {
		// TODO Auto-generated method stub
		op.returnCoin(); //Invoke returnCoin method
	}

	@Override
	public void card() {
		// TODO Auto-generated method stub
		System.out.println("Cannot perform the operation in S3 state");
	}

	@Override
	public void additive(int a) {
		// TODO Auto-generated method stub
		if(m.A[a]==0) {
			m.A[a]=1;
			System.out.println("Additive selected"); //Increase the additive to 1 if not selected
			
		}
		else {
			m.A[a]=0;
			System.out.println("Additive de-selected");//Increase the additive to 0 if selected
		}
		//System.out.println(m.A[a]);
	}

	@Override
	public void dispose_drink() {
		// TODO Auto-generated method stub
		if(m.k>1) {
			op.dispose_with_add(m.A);
			m.k=m.k-1;
			m.setState(2);//If the cups is more than 1 invoke dispose_with_add and decrement by 1 and changes the state to S2
		}
		else {
			op.dispose_with_add(m.A);
			m.k=m.k-1;
			m.setState(1);//If the cups is more than 1 invoke dispose_with_add and decrement by 1 and changes the state to S1
		}
	}

	@Override
	public void insertCups(int n) {
		// TODO Auto-generated method stub
		System.out.println("Cannot perform the operation in S3 state");
	}

	@Override
	public void set_price() {
		// TODO Auto-generated method stub
		System.out.println("Cannot perform the operation in S3 state");
	}

	@Override
	public void cancel() {
		// TODO Auto-generated method stub
		op.returnCoin();
		op.init_cp();
		m.setState(2);//Invoke returnCoin and init_cp and changes the state to S2
	}

}
