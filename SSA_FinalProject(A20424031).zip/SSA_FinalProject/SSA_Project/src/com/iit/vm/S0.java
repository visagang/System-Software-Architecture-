package com.iit.vm;
//This class inherits the State class and represent the Initial State.
public class S0 extends State{

	@Override
	public void create() {
		// TODO Auto-generated method stub
	op.StorePrice();
	//System.out.println("In SO");
	//m.k=0;
    //m.setM(1);
    m.setState(1); //Invokes the StorePrice and changes the state to S1
	}

	@Override
	public void coin(int f) {
		// TODO Auto-generated method stub
	System.out.println("Cannot perform the operation in S0 state");
	}

	@Override
	public void card() {
		// TODO Auto-generated method stub
		System.out.println("Cannot perform the operation in S0 state");	
	}

	@Override
	public void additive(int a) {
		// TODO Auto-generated method stub
		System.out.println("Cannot perform the operation in S0 state");
	}

	@Override
	public void dispose_drink() {
		// TODO Auto-generated method stub
		System.out.println("Cannot perform the operation in S0 state");
	}

	@Override
	public void insertCups(int n) {
		// TODO Auto-generated method stub
		System.out.println("Cannot perform the operation in S0 state");
	}

	@Override
	public void set_price() {
		// TODO Auto-generated method stub
		System.out.println("Cannot perform the operation in S0 state");
	}

	@Override
	public void cancel() {
		// TODO Auto-generated method stub
		System.out.println("Cannot perform the operation in S0 state");
	}

}
