package com.iit.vm;
//This class inherits the add_cp and is used by VM_1.
public class dispose_with_add1 extends dispose_with_add{

	@Override
	public void dispose_with_add(DataStore ds, int[] A) {
		// TODO Auto-generated method stub
		int x=ds.get_drink_type(); //The method gets the drink type selected and checks if any additives are present and then dispose them accordingly.
		if(x==1) {
			System.out.println("Tea is disposed");
			ds.set_cp(0);
			if(A[0]==1) {
			System.out.println("Sugar is disposed");
		}
		if(A[1]==1)
			System.out.println("Cream is disposed");
		}
		if(x==2) {
			System.out.println("Chocolate is disposed");
			ds.set_cp(0);
			if(A[0]==1) {
				System.out.println("Sugar is disposed");
			}
			if(A[1]==1)
				System.out.println("Cream is disposed");
		}
	}

}
