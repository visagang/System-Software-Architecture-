package com.iit.vm;
//This is a class that contains a list of meta actions to take place based on the meta events invoked.
public class OutputProcessor {
private DataStore ds;
int A[]=new int[3];//integer array to represent a list of additives
private StorePrice sp;
private init_cp ic;
private returnCoin rc;
private add_cp ac;
private dispose_with_add da;
private InitializeData initializeData;
//pointer to all the strategy pattern ...i.e all the methods
public void Initialize(AbstractFactory af){
    ds = af.getDataStore();

    sp = af.createStorePrice();
    ic=af.createinit_cp();
    rc=af.createreturnCoin();
    ac=af.createadd_cp();
    da=af.createdispose_with_add();
    initializeData = af.CreateInitializeData(); // It is an example of abstract-factory pattern where the AbstractFactory object is used to create new objects for each and every strategy class.
  }

//It is used to invoke the methods of particular strategy class.
public void StorePrice() {
	sp.StorePrice(ds);	
}
public void init_cp() {
	ic.init_cp(ds);
}
public void returnCoin() {
	rc.returnCoin(ds);
}
public void add_cp() {
	ac.add_cp(ds);
}
public void dispose_with_add(int A[]) {
	da.dispose_with_add(ds,A);
}
}
