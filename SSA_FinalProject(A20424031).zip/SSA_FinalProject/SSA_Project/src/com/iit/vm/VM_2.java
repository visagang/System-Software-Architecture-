package com.iit.vm;

public class VM_2 {
	private DataStore d;
	 private MDAEFSM m;
	 
	 public void Initialize(AbstractFactory af){
		  d = af.getDataStore();
		  m = new MDAEFSM();
		  m.Initialize(af);
	}
	 
	 void CREATE(float p) {
		 d.set_temp_p(p);
		 m.create(); 
	 }

	 void COIN(float v) {
		 d.set_temp_v(v);
		 if (d.get_cp1()+v>=d.get_price1())
			 m.coin(1);
		else 
			m.coin(0); 
		 System.out.println("The cp value is "+d.get_cp1());
	 }
	 	 
	 void SUGAR() {
		 m.additive(0);
	 } 
	 
	 void CREAM() {
		 m.additive(1);
	 }
	 void COFFEE() {
		 d.set_drink_type(3);
		 m.dispose_drink();
	 }
		 
	 void InsertCups(int n) {
		 m.insertCups(n);
		 System.out.println("Number of cups "+m.k);
	 }
	 
	 void SetPrice(float p) {
		 d.set_temp_p(p);
		 m.set_price();
	 }
	 
	 void CANCEL() {
		 m.cancel();
	 }

}
